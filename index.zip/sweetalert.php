<?php ?>
<script src="library/sweetalert2/sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="library/sweetalert2/sweetalert2.min.css">