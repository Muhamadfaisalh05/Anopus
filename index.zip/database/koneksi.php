<?php 
// Database
$hostname = "localhost";
$username = "idarmabi_anopus";
$password = "Ibndrma1502#";
$database = "idarmabi_puskesmas";

// Memasukan Koneksi ke dalam variable
$koneksi = mysqli_connect($hostname,$username,$password,$database);

?>